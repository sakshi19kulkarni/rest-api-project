package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Student;
import com.example.demo.error.StudentNotFoundException;

public interface StudentService {

	Student saveStudent(Student student);

	List<Student> fetchStudList();

	Student fetchStudentById(Long did) throws StudentNotFoundException;

	void deleteStudentById(Long did) throws StudentNotFoundException;

	
	Student fetchStudentByName(String studentName);

	Student fetchStudentByEmail(String studentEmail);

	Student updateStudent(Long did, Student student);

}
	
	


	



