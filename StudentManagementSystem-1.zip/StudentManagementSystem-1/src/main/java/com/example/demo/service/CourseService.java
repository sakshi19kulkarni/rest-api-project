package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Course;





public interface CourseService {

	
		//List<Course> fetchcourList();

		Course saveCourse(Course course);

		List<Course> fetchcourList();

	}